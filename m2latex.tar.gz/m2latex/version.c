char* version_string = "m2latex Version 1.0, Patchlevel 1";
